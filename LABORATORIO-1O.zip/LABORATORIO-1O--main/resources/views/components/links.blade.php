<div style="display: flex; justify-content: space-around; margin-top: 10px; width: 20%;">
<div>
<a href="https://laravel.com" target="_blank">Laravel</a>
</div>
<div>
<a href="https://getbootstrap.com" target="_blank">Bootstrap</a>
</div>
<div>
<a href="https://tailwindcss.com" target="_blank">Tailwind</a>
</div>
</div>
