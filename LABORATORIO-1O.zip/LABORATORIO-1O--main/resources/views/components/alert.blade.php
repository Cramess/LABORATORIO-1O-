<div style="background-color: {{ $color }}; width: 20%; margin-top: 5px; padding: 5px;">
{{ $message }}
</div>
